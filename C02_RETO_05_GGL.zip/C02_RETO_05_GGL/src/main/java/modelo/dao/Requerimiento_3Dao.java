// GGL: Reto 05 - Carperta DAO, Requerimiento 3 
package modelo.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.vo.Requerimiento_3Vo;
import util.JDBCUtilities;

//pr.ID_Proyecto, mc.NombreMaterial, filtro pr.Ciudad
public class Requerimiento_3Dao {
    public ArrayList<Requerimiento_3Vo> requerimiento3() throws SQLException {
        Connection connection = JDBCUtilities.getConnection();
        ArrayList<Requerimiento_3Vo> listado_registros_rq3 = new ArrayList<Requerimiento_3Vo>();
        String sql_03 = "SELECT pr.ID_Proyecto, mc.Nombre_Material FROM Proyecto pr JOIN Compra cr ON (pr.ID_Proyecto = cr.ID_Proyecto) JOIN MaterialConstruccion mc ON (cr.ID_MaterialConstruccion = mc.ID_MaterialConstruccion) WHERE pr.ID_Proyecto BETWEEN 40 AND 55 ORDER BY pr.ID_Proyecto ASC;";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql_03)) {
            while (rs.next()) {
                Requerimiento_3Vo requerimiento3 = new Requerimiento_3Vo();
                requerimiento3.setIdProyecto(rs.getInt("ID_Proyecto"));
                requerimiento3.setMaterial(rs.getString("Nombre_Material"));
                listado_registros_rq3.add(requerimiento3);
            }
        }
        return listado_registros_rq3;
    }
}