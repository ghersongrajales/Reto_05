// GGL: Reto 05 - Carperta DAO, Requerimiento 1 
package modelo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.vo.Requerimiento_1Vo;
import util.JDBCUtilities;


//Ciudad_Residencia, Promedio Salario, filtro < 400000
public class Requerimiento_1Dao {
    public ArrayList<Requerimiento_1Vo> requerimiento1() throws SQLException {
        Connection connection = JDBCUtilities.getConnection();
        ArrayList<Requerimiento_1Vo> listado_registros_rq1 = new ArrayList<Requerimiento_1Vo>();
        String sql_01 = "SELECT Ciudad_Residencia, AVG(Salario) AS Promedio FROM Lider GROUP BY Ciudad_Residencia HAVING AVG(Salario) < 400000 ORDER BY Promedio DESC;";
        // DefaultTableModel vTabla = new DefaultTableModel();
        // JTable vRequerimientos = new JTable(vTabla);
        // vRequerimientos.setModel(vTabla);
        // vRequerimientos.setPreferredScrollableViewportSize(new Dimension(250, 150));
        // JScrollPane scrollpane = new JScrollPane(vRequerimientos);
        // add(scrollPane);

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql_01)) {
            while (rs.next()) {
                // Object[] filanueva = { rs.getString("Ciudad_REsidencia"),
                // rs.getDouble("Promedio") };
                // vTabla.addRow(filanueva);
                Requerimiento_1Vo requerimiento1 = new Requerimiento_1Vo();
                requerimiento1.setCiudadResidencia(rs.getString("Ciudad_REsidencia"));
                requerimiento1.setPromedio(rs.getDouble("Promedio"));
                listado_registros_rq1.add(requerimiento1);
            }
        }
        return listado_registros_rq1;
    }

}