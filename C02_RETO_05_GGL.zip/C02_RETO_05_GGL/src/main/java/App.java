// GGL: Reto 05 - Aplicacion patron MVC
import vista.VistaRequerimientos;

public class App {
public static void main(String[] args) throws Exception {
        VistaRequerimientos.requerimiento1();
//        System.out.println();

        VistaRequerimientos.requerimiento2();
//       System.out.println();

        VistaRequerimientos.requerimiento3();
//        System.out.println();
    }
}