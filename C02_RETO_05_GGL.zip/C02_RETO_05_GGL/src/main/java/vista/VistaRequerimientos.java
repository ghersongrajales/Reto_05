package vista;

import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import controlador.Controller;
import modelo.vo.Requerimiento_1Vo;
import modelo.vo.Requerimiento_2Vo;
import modelo.vo.Requerimiento_3Vo;

public class VistaRequerimientos {

    public static final Controller controlador = new Controller();

  
//Ciudad_Residencia, Promedio Salario, filtro < 400000
    public static void requerimiento1() {
    
        try {
            ArrayList<Requerimiento_1Vo> resultado_requerimiento1 = controlador.consultarRequerimiento1();
//            resultado_requerimiento1.forEach(System.out::println);
            String datos1 = "\nCiudad          Promedio\n";
            JFrame vLista = new JFrame(datos1);
            for (Requerimiento_1Vo req1:resultado_requerimiento1) {
             datos1 += req1.getCiudadResidencia();
             datos1 += "    " + req1.getPromedio();
             datos1 += "\n";
            }
            JTextArea tArea = new JTextArea(datos1);
            tArea.setBounds(10,30,200, 200);
            vLista.add(tArea);
            vLista.setSize(400,500);
            vLista.setVisible(true);            

        } catch (Exception e) {
            System.out.println("Se ha producido el siguiente error:" + e.getMessage());
            e.printStackTrace();
        }
    }

//pr.ID_Proyecto, cr.Proveedor, filtro pr.Ciudad
    public static void requerimiento2() {
        try {
            ArrayList<Requerimiento_2Vo> resultado_requerimiento2 = controlador.consultarRequerimiento2();
//            resultado_requerimiento2.forEach(System.out::println);
            String datos02 = "\nProyecto    Proveedor\n";
            JFrame vLista = new JFrame(datos02);
            for (Requerimiento_2Vo req2:resultado_requerimiento2) {
             datos02 += req2.getIdProyecto();
             datos02 += "    " + req2.getProveedor();
             datos02 += "\n";            
            }
            JTextArea tArea = new JTextArea(datos02);
            tArea.setBounds(10,30,200, 200);
            vLista.add(tArea);
            vLista.setSize(400,500);
            vLista.setVisible(true);            
        } catch (Exception e) {
            System.out.println("Se ha producido el siguiente error:" + e.getMessage());
            e.printStackTrace();
        }
    }

//pr.ID_Proyecto, mc.NombreMaterial, filtro pr.Ciudad
    public static void requerimiento3() {
        try {
            ArrayList<Requerimiento_3Vo> resultado_requerimiento3 = controlador.consultarRequerimiento3();
//            resultado_requerimiento3.forEach(System.out::println);

            String datos03 = "\nProyecto    Materiales\n";
            JFrame vLista = new JFrame(datos03);
            for (Requerimiento_3Vo req3:resultado_requerimiento3) {
                datos03 += req3.getIdProyecto();
                datos03 += "    " + req3.getMaterial();
                datos03 += "\n";  
            }
            JTextArea tArea = new JTextArea(datos03);
            tArea.setBounds(10,30,200, 200);
            vLista.add(tArea);
            vLista.setSize(400,500);
            vLista.setVisible(true);            

        } catch (Exception e) {
            System.out.println("Se ha producido el siguiente error:" + e.getMessage());
            e.printStackTrace();
        }
    }

}
